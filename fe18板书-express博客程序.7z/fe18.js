// 此为第 18 课的上课内容
//
// 今天的内容是
/*
使用下面的功能实现博客程序
node
express
ajax


文件分布如下
- appBlog.js        后端程序主文件
- blog.js           处理 blog 数据存取的文件
- blog.json         存储 blog 数据的文件(相当于数据库)
- blog_index.html   博客主页的 html 文件
- blog_detail.html  博客详情页面 html 文件


运行程序方式如下
node appBlog.js


这只是初步的程序, 上课会增加所有必须的功能
*/
